
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Coins, Sword, Pickaxe, Gamepad2, Zap, Crown, Shield } from "lucide-react";

const web3Games = [
  {
    name: "Gala Games",
    description: "Blockchain gaming ecosystem with player ownership",
    url: "https://games.gala.com/",
    icon: Coins,
    category: "Blockchain Gaming",
    gradient: "from-yellow-500 to-orange-500"
  },
  {
    name: "Axie Infinity",
    description: "Play-to-earn digital pet universe",
    url: "https://axieinfinity.com/",
    icon: Sword,
    category: "Play-to-Earn",
    gradient: "from-blue-500 to-purple-500"
  },
  {
    name: "GoMining - Miner Wars",
    description: "Cryptocurrency mining strategy game",
    url: "https://gomining.com/miner-wars",
    icon: Pickaxe,
    category: "Mining Game",
    gradient: "from-green-500 to-blue-500"
  },
  {
    name: "Illuvium",
    description: "Open-world RPG adventure on blockchain",
    url: "https://illuvium.io/",
    icon: Sword,
    category: "RPG",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    name: "Pixels",
    description: "Farming metaverse with NFT integration",
    url: "https://www.pixels.xyz/",
    icon: Crown,
    category: "Metaverse",
    gradient: "from-green-400 to-emerald-500"
  },
  {
    name: "Yield Guild Games",
    description: "Web3 gaming guild and ecosystem",
    url: "https://www.yieldguild.io/web3-games",
    icon: Shield,
    category: "Gaming Guild",
    gradient: "from-indigo-500 to-purple-600"
  },
  {
    name: "NAKA Runner Xtreme",
    description: "High-speed blockchain runner game",
    url: "https://www.nakamoto.games/standalone/naka-runner-xtreme",
    icon: Zap,
    category: "Arcade",
    gradient: "from-red-500 to-orange-500"
  },
  {
    name: "Strike Force",
    description: "Tactical combat blockchain game",
    url: "https://www.nakamoto.games/standalone/strike-force",
    icon: Sword,
    category: "Action",
    gradient: "from-gray-600 to-gray-800"
  },
  {
    name: "Dawn of the Damned",
    description: "Multiplayer survival horror game",
    url: "https://www.nakamoto.games/standalone/dawn-of-the-damned/roomlist",
    icon: Shield,
    category: "Horror",
    gradient: "from-red-600 to-black"
  },
  {
    name: "NAKA Mahjong",
    description: "Classic Mahjong with crypto rewards",
    url: "https://www.nakamoto.games/play-to-earn/mahjong",
    icon: Gamepad2,
    category: "Puzzle",
    gradient: "from-teal-500 to-cyan-600"
  },
  {
    name: "NAKA Strike",
    description: "Competitive bowling with earnings",
    url: "https://www.nakamoto.games/play-to-earn/naka-strike",
    icon: Coins,
    category: "Sports",
    gradient: "from-blue-600 to-indigo-700"
  },
  {
    name: "Spooky Run 2",
    description: "Free-to-play horror runner game",
    url: "https://www.nakamoto.games/free-to-play/spooky-run-2-free-to-play",
    icon: Zap,
    category: "Free-to-Play",
    gradient: "from-orange-600 to-red-600"
  },
  {
    name: "Road Rush",
    description: "Free racing game with blockchain integration",
    url: "https://www.nakamoto.games/free-to-play/road-rush-free-to-play",
    icon: Gamepad2,
    category: "Racing",
    gradient: "from-yellow-500 to-red-500"
  },
  {
    name: "Blocky Pets",
    description: "Free pet collection and battle game",
    url: "https://www.nakamoto.games/free-to-play/blocky-pets-free-to-play",
    icon: Crown,
    category: "Pets",
    gradient: "from-pink-500 to-purple-500"
  },
  {
    name: "MARBLEX",
    description: "NFT gaming platform with multiple titles",
    url: "https://www.marblex.io/en/fun?nm_to=nft",
    icon: Coins,
    category: "NFT Platform",
    gradient: "from-violet-500 to-purple-600"
  },
  {
    name: "Seraph",
    description: "Blockchain gaming ecosystem",
    url: "https://www.seraph.game/#/games",
    icon: Shield,
    category: "Gaming Platform",
    gradient: "from-cyan-500 to-blue-600"
  },
  {
    name: "Off The Grid",
    description: "Battle royale with player-owned assets",
    url: "https://gameoffthegrid.com/",
    icon: Sword,
    category: "Battle Royale",
    gradient: "from-emerald-500 to-teal-600"
  }
];

export const Web3Games = () => {
  return (
    <section id="web3-games" className="py-20 px-6 bg-gray-900/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            Web3 & Blockchain Games
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Experience the future of gaming with true digital ownership and play-to-earn mechanics
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {web3Games.map((game, index) => {
            const IconComponent = game.icon;
            return (
              <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-yellow-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-yellow-500/10">
                <CardHeader className="text-center pb-4">
                  <div className={`mx-auto p-3 rounded-full bg-gradient-to-r ${game.gradient} w-fit mb-3`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-white text-base leading-tight">{game.name}</CardTitle>
                  <CardDescription className="text-gray-400 text-xs leading-tight">
                    {game.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-center space-y-3">
                    <span className="inline-block px-2 py-1 text-xs font-semibold bg-yellow-500/20 text-yellow-400 rounded-full">
                      {game.category}
                    </span>
                    <Button
                      className={`w-full bg-gradient-to-r ${game.gradient} hover:opacity-90 text-white font-semibold text-sm py-2`}
                      onClick={() => window.open(game.url, '_blank')}
                    >
                      <ExternalLink className="w-3 h-3 mr-2" />
                      Play Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
