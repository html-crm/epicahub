
import { Gamepad2, Github, Twitter, MessageCircle } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-gray-900/80 backdrop-blur-sm border-t border-gray-700 py-8 sm:py-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-6 sm:mb-8">
          <div className="flex justify-center items-center gap-3 mb-4">
            <Gamepad2 className="w-6 h-6 sm:w-8 sm:h-8 text-cyan-400" />
            <h3 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              EPICA HUB GAMING
            </h3>
          </div>
          <p className="text-gray-400 max-w-2xl mx-auto text-sm sm:text-base px-4">
            Your ultimate destination for Web3 gaming, metaverse experiences, and blockchain-powered adventures. 
            Discover the future of gaming today.
          </p>
        </div>
        
        <div className="flex justify-center gap-4 sm:gap-6 mb-6 sm:mb-8">
          <a 
            href="#" 
            className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
            aria-label="Twitter"
          >
            <Twitter className="w-5 h-5 sm:w-6 sm:h-6" />
          </a>
          <a 
            href="#" 
            className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
            aria-label="Discord"
          >
            <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6" />
          </a>
          <a 
            href="#" 
            className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
            aria-label="GitHub"
          >
            <Github className="w-5 h-5 sm:w-6 sm:h-6" />
          </a>
        </div>
        
        <div className="text-center text-gray-500 text-xs sm:text-sm px-4">
          <p>&copy; 2024 Epica Hub Gaming. All rights reserved. | Built for the future of gaming</p>
        </div>
      </div>
    </footer>
  );
};
