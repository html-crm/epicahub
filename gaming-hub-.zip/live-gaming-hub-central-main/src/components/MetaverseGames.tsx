
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Globe, MapPin, Zap } from "lucide-react";

const metaverseGames = [
  {
    name: "The Sandbox",
    description: "Create, own, and monetize your gaming experiences",
    url: "https://www.sandbox.game/en/",
    icon: Globe,
    category: "Metaverse",
    gradient: "from-cyan-500 to-blue-500",
    experiences: [
      {
        title: "Attack on Titan: Invasion",
        url: "https://www.sandbox.game/en/experiences/Attack%20on%20Titan:%20Invasion/f63382c1-05a2-45cb-b3e2-027dbdf3c898/page/"
      },
      {
        title: "Terminator 2042",
        url: "https://www.sandbox.game/en/experiences/Terminator%202042/8c69d9de-8e6d-47e4-a7ca-93743754c351/page/"
      },
      {
        title: "Alpha Season 5 Hub",
        url: "https://www.sandbox.game/en/experiences/Alpha%20Season%205%20Hub/947c7f66-564e-45b8-9486-5e4007ef113d/page/"
      }
    ]
  },
  {
    name: "Decentraland",
    description: "Virtual reality platform powered by Ethereum",
    url: "https://decentraland.org/",
    icon: MapPin,
    category: "Virtual World",
    gradient: "from-purple-500 to-pink-500"
  }
];

export const MetaverseGames = () => {
  return (
    <section id="metaverse" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
            Metaverse Worlds
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Step into immersive virtual worlds where imagination becomes reality
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {metaverseGames.map((world, index) => {
            const IconComponent = world.icon;
            return (
              <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-pink-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-pink-500/10">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className={`p-4 rounded-xl bg-gradient-to-r ${world.gradient}`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-white text-2xl">{world.name}</CardTitle>
                      <CardDescription className="text-gray-400 text-lg">
                        {world.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <span className="inline-block px-4 py-2 text-sm font-semibold bg-pink-500/20 text-pink-400 rounded-full">
                    {world.category}
                  </span>
                  
                  {world.experiences && (
                    <div className="space-y-3">
                      <h4 className="text-lg font-semibold text-pink-400 flex items-center gap-2">
                        <Zap className="w-5 h-5" />
                        Featured Experiences
                      </h4>
                      <div className="grid gap-2">
                        {world.experiences.map((experience, expIndex) => (
                          <Button
                            key={expIndex}
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-gray-300 hover:text-pink-400 hover:bg-pink-500/10 p-3"
                            onClick={() => window.open(experience.url, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4 mr-3" />
                            {experience.title}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <Button
                    className={`w-full bg-gradient-to-r ${world.gradient} hover:opacity-90 text-white font-semibold py-3 text-lg`}
                    onClick={() => window.open(world.url, '_blank')}
                  >
                    <Globe className="w-5 h-5 mr-2" />
                    Enter {world.name}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
