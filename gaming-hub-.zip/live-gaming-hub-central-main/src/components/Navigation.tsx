
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Gamepad2, Menu, X, Github, Twitter, MessageCircle } from "lucide-react";

export const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-sm border-b border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-8 h-8 text-cyan-400" />
            <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              EPICA HUB
            </span>
          </div>

          {/* Social Media Icons - Desktop */}
          <div className="hidden md:flex items-center gap-4">
            <a 
              href="#" 
              className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              aria-label="Twitter"
            >
              <Twitter className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              aria-label="Discord"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              aria-label="GitHub"
            >
              <Github className="w-5 h-5" />
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => scrollToSection('platforms')}
              className="text-gray-300 hover:text-cyan-400 transition-colors duration-300"
            >
              Platforms
            </button>
            <button 
              onClick={() => scrollToSection('web3-games')}
              className="text-gray-300 hover:text-cyan-400 transition-colors duration-300"
            >
              Web3 Games
            </button>
            <button 
              onClick={() => scrollToSection('metaverse')}
              className="text-gray-300 hover:text-cyan-400 transition-colors duration-300"
            >
              Metaverse
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleMenu}
              className="text-gray-300 hover:text-cyan-400"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-800/95 backdrop-blur-sm border-t border-gray-700">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {/* Social Media Icons - Mobile */}
              <div className="flex justify-center gap-6 py-4 border-b border-gray-700 mb-4">
                <a 
                  href="#" 
                  className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
                  aria-label="Twitter"
                >
                  <Twitter className="w-6 h-6" />
                </a>
                <a 
                  href="#" 
                  className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
                  aria-label="Discord"
                >
                  <MessageCircle className="w-6 h-6" />
                </a>
                <a 
                  href="#" 
                  className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
                  aria-label="GitHub"
                >
                  <Github className="w-6 h-6" />
                </a>
              </div>
              
              <button 
                onClick={() => scrollToSection('platforms')}
                className="block w-full text-left px-3 py-2 text-gray-300 hover:text-cyan-400 transition-colors duration-300"
              >
                Platforms
              </button>
              <button 
                onClick={() => scrollToSection('web3-games')}
                className="block w-full text-left px-3 py-2 text-gray-300 hover:text-cyan-400 transition-colors duration-300"
              >
                Web3 Games
              </button>
              <button 
                onClick={() => scrollToSection('metaverse')}
                className="block w-full text-left px-3 py-2 text-gray-300 hover:text-cyan-400 transition-colors duration-300"
              >
                Metaverse
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
