
import { Button } from "@/components/ui/button";
import { Gamepad2, Zap, Globe } from "lucide-react";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-cyan-900/20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%239C92AC%22%20fill-opacity%3D%220.1%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] animate-pulse"></div>
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-6xl mx-auto">
        <div className="flex justify-center mb-6 sm:mb-8">
          <div className="relative">
            <Gamepad2 className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 text-cyan-400 animate-bounce" />
            <div className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2">
              <Zap className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-yellow-400 animate-pulse" />
            </div>
          </div>
        </div>
        
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-8xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-pulse">
          EPICA HUB GAMING
        </h1>
        
        <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-6 sm:mb-8 max-w-3xl mx-auto leading-relaxed px-2">
          Your ultimate gateway to the world of Web3 gaming, metaverse experiences, and blockchain-powered adventures
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center">
          <Button 
            size="lg" 
            className="w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-cyan-500/25"
            onClick={() => document.getElementById('platforms')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <Globe className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
            Explore Games
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            className="w-full sm:w-auto border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-900 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold transform hover:scale-105 transition-all duration-300"
            onClick={() => document.getElementById('web3-games')?.scrollIntoView({ behavior: 'smooth' })}
          >
            <Zap className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
            Web3 Gaming
          </Button>
        </div>
      </div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-4 sm:left-10 w-3 h-3 sm:w-4 sm:h-4 bg-cyan-400 rounded-full animate-ping"></div>
      <div className="absolute bottom-20 right-4 sm:right-10 w-4 h-4 sm:w-6 sm:h-6 bg-purple-400 rounded-full animate-pulse"></div>
      <div className="absolute top-1/2 right-8 sm:right-20 w-2 h-2 sm:w-3 sm:h-3 bg-pink-400 rounded-full animate-bounce"></div>
    </section>
  );
};
