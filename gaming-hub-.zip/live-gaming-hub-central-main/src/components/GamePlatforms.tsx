
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Gamepad2, Trophy, Users } from "lucide-react";

const platforms = [
  {
    name: "BinaryX Pro",
    description: "Advanced gaming platform with multiple game modes",
    url: "https://binaryx.pro/",
    icon: Gamepad2,
    games: [
      { title: "Game Detail 2", url: "https://binaryx.pro/game/detail/2" },
      { title: "Game Detail 5", url: "https://binaryx.pro/game/detail/5" }
    ],
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    name: "Immutable Games",
    description: "Next-generation gaming on Ethereum",
    url: "https://play.immutable.com/games/",
    icon: Trophy,
    gradient: "from-purple-500 to-pink-500"
  },
  {
    name: "Ronin Games",
    description: "Marketplace for Ronin blockchain games",
    url: "https://marketplace.roninchain.com/games",
    icon: Users,
    gradient: "from-green-500 to-emerald-500"
  },
  {
    name: "Bora Portal",
    description: "Portal to diverse gaming experiences",
    url: "https://www.boraportal.com/play/",
    icon: Gamepad2,
    gradient: "from-orange-500 to-red-500"
  }
];

export const GamePlatforms = () => {
  return (
    <section id="platforms" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Gaming Platforms
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover cutting-edge gaming platforms that are revolutionizing the industry
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {platforms.map((platform, index) => {
            const IconComponent = platform.icon;
            return (
              <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-cyan-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/10">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-lg bg-gradient-to-r ${platform.gradient}`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-white text-xl">{platform.name}</CardTitle>
                      <CardDescription className="text-gray-400">
                        {platform.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {platform.games && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-semibold text-cyan-400">Featured Games:</h4>
                      {platform.games.map((game, gameIndex) => (
                        <Button
                          key={gameIndex}
                          variant="ghost"
                          size="sm"
                          className="w-full justify-start text-gray-300 hover:text-cyan-400 hover:bg-cyan-500/10"
                          onClick={() => window.open(game.url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          {game.title}
                        </Button>
                      ))}
                    </div>
                  )}
                  <Button
                    className={`w-full bg-gradient-to-r ${platform.gradient} hover:opacity-90 text-white font-semibold`}
                    onClick={() => window.open(platform.url, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Visit Platform
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};
