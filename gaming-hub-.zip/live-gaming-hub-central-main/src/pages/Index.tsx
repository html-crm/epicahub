
import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { GamePlatforms } from "@/components/GamePlatforms";
import { Web3Games } from "@/components/Web3Games";
import { MetaverseGames } from "@/components/MetaverseGames";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      <Navigation />
      <Hero />
      <GamePlatforms />
      <Web3Games />
      <MetaverseGames />
      <Footer />
    </div>
  );
};

export default Index;
